import App from "../../src/main";
export default function Page(){return <App initialPath="/privacy"/>;}
